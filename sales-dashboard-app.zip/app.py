from flask import Flask, render_template, request
import pandas as pd
from data_analysis import generate_charts

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        df = pd.read_csv(file)
        chart_paths = generate_charts(df)
        return render_template('dashboard.html', charts=chart_paths)
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)