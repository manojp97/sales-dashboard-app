import pandas as pd
import matplotlib.pyplot as plt
import os

IMAGE_FOLDER = 'static/images/'

def clean_images():
    for file in os.listdir(IMAGE_FOLDER):
        if file.endswith('.png'):
            os.remove(os.path.join(IMAGE_FOLDER, file))

def generate_charts(df):
    clean_images()
    chart_paths = []

    df['Total'] = df['Quantity'] * df['Price']
    sales_by_product = df.groupby('Product')['Total'].sum()
    plt.figure(figsize=(6, 4))
    sales_by_product.plot(kind='bar', color='skyblue')
    plt.title('Total Sales by Product')
    plt.ylabel('Total Amount')
    plt.tight_layout()
    path1 = os.path.join(IMAGE_FOLDER, 'sales_by_product.png')
    plt.savefig(path1)
    chart_paths.append(path1)
    plt.close()

    df['Date'] = pd.to_datetime(df['Date'])
    df['Month'] = df['Date'].dt.to_period('M')
    monthly_sales = df.groupby('Month')['Total'].sum()
    plt.figure(figsize=(6, 4))
    monthly_sales.plot(kind='line', marker='o', color='orange')
    plt.title('Monthly Sales Trend')
    plt.ylabel('Total Amount')
    plt.xticks(rotation=45)
    plt.tight_layout()
    path2 = os.path.join(IMAGE_FOLDER, 'monthly_sales.png')
    plt.savefig(path2)
    chart_paths.append(path2)
    plt.close()

    profit_by_product = df.groupby('Product')['Profit'].sum()
    plt.figure(figsize=(6, 4))
    profit_by_product.plot(kind='pie', autopct='%1.1f%%', startangle=140)
    plt.title('Profit Share by Product')
    plt.ylabel('')
    plt.tight_layout()
    path3 = os.path.join(IMAGE_FOLDER, 'profit_share.png')
    plt.savefig(path3)
    chart_paths.append(path3)
    plt.close()

    return chart_paths